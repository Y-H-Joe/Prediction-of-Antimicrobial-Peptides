# -*- coding: utf-8 -*-
"""
Created on Wed Mar 21 17:10:48 2018

@author: 23712
"""
from sklearn.ensemble import RandomForestClassifier
from sklearn.svm import SVC
import xgboost as xgb

def D_XG(XY_train,XY_test):
  train_X=XY_train[:,:-1];train_Y=XY_train[:,-1];
  test_X=XY_test[:,:-1];test_Y=XY_test[:,-1];
  #要把y label暂时从3转成2，进行xgboost，再将prediction里的2转回3
  temp_train=[2 if x==3 else x for x in train_Y]
  temp_test=[2 if x==3 else x for x in test_Y]
  
  xg_train = xgb.DMatrix(train_X, label=temp_train)
  xg_test = xgb.DMatrix(test_X, label=temp_test)
  # setup parameters for xgboost
  param = {}
  # use softmax multi-class classification
  param['objective'] = 'multi:softmax'
  # scale weight of positive examples
  param['eta'] = 0.1
  param['max_depth'] = 6
  param['silent'] = 1
  param['nthread'] = 4
  param['num_class'] = 3
  
  #watchlist = [(xg_train, 'train'), (xg_test, 'test')]
  num_round = 5
  bst = xgb.train(param, xg_train, num_round)
  # get prediction
  pred = list(bst.predict(xg_test))
  Predicitions=[3 if x==2 else x for x in pred]
  return Predicitions
  

def PCA_PCM_SVM(XY_train,XY_test):
  clf=SVC()
  X_train=[];X_test=[];Y_train=[];Y_test=[];#让train。test有序分组，X，Y的对应顺序不乱
  for xy_train in XY_train:
    X_train.append(xy_train[:-1])
    Y_train.append(xy_train[-1])
  for xy_test in XY_test:
    X_test.append(xy_test[:-1])
    Y_test.append(xy_test[-1])        
  clf.fit(X_train,Y_train)
  Predictions=clf.predict(X_test)
  return list(Predictions)

def PCA_PCM_RF(XY_train,XY_test):
  clf=RandomForestClassifier()
  X_train=[];X_test=[];Y_train=[];Y_test=[];#让train。test有序分组，X，Y的对应顺序不乱
  for xy_train in XY_train:
    X_train.append(xy_train[:-1])
    Y_train.append(xy_train[-1])
  for xy_test in XY_test:
    X_test.append(xy_test[:-1])
    Y_test.append(xy_test[-1])        
  clf.fit(X_train,Y_train)
  Predictions=clf.predict(X_test)
  return list(Predictions)


