# -*- coding: utf-8 -*-
"""
Created on Sat Jan 20 15:43:00 2018

@author: 23712
"""
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report,confusion_matrix
import csv
import time
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
'''
#先把每个aa的六维理化性质导入
AAindex=pd.read_csv('../PCA_PCM_DATA.csv')
#每条多肽链都用六维理化性质表示，长度虽不同都用平均值

def PrePareData(self):
  Num=19
  print(Num)
  XY=[];#X装六维理化性质， Y装对应的Label
  for name in self:
    if name=='Zero':y=0;
    else:     
      if name=='AntiGN':y=1;      
      else:
        if name=='AntiGP':y=2;
        else: y=3
    Name=str(name+'.txt')
    with open(Name) as f:
      for line in f.readlines():
        if (line[0]=='>' or len(line)<4):continue #把AMP序列号和太短的AMP筛除
        line=list(line.strip()) #筛出来的AMP打成一个个氨基酸
        count=0 #count用来计数一条链有几个氨基酸好算平均数
        Indexofline=[0 for x in range(Num)]# 用来暂时盛放一条多肽链的六维理化性质数据    
        Indexofline2=[]
        for aa in line:
          count+=1
          for i in range(20):
            if aa==AAindex.iloc[i,0]: 
              for j in range(Num): Indexofline[j]+=AAindex.iloc[i,j+1]#把每个氨基酸的六维理化性质累加起来
        for i in Indexofline: 
          Indexofline2.append(float(i/count))#list不能操作自己，故转移到另一个list 
        Indexofline2.append(y)
        XY.append(Indexofline2)#XY把理化性质和label打包，使后续training时shuffle split不会乱掉        
  return XY
'''
data_T=np.loadtxt("./Data/Fin-Two-2-0_5-5.csv",delimiter=',')
data_P=np.loadtxt("./Data/Fin-Pos-2-0_5-5.csv",delimiter=',')
data_Z=np.loadtxt("./Data/Fin-Zero-2-0_5-5.csv",delimiter=',')
data_N=np.loadtxt("./Data/Fin-Neg-2-0_5-5.csv",delimiter=',')
XY=np.concatenate((data_N,data_P,data_T,data_Z),axis=0)
data_X=XY[:,:-1]
data_X_S=StandardScaler().fit_transform(data_X)
PCA_data_X=PCA(n_components=50).fit_transform(data_X)
data=np.concatenate((PCA_data_X,[[x] for x in XY[:,-1]]),axis=1)
#计算待测多肽链与训练集中所有多肽链的距离并以[距离，y]的形式返回
#K条最近的，由小到大排列
def Distance(test,train,k):
  Dis={}
  for i in train:
    Dis.update({np.linalg.norm(np.array(test[:-1])-np.array(i[:-1])):i[-1]})
  Dis=sorted(Dis.items(),key=lambda i:i[0])
  return Dis[:k]#排序后选择前k个，格式为[(距离, y),...]
  
def Predict(test,Fi):
  test=np.matrix(test)#转成矩阵好运算,然后计算+，-性对应的隶属度值哪个高
  Denominator=0;AntiGN_Num=0;
  AntiGP_Num=0;
  if test[0,1]==0:#如果最近的向量抗性为0or2，则无需再预测
    return 0
  else:
    if test[0,1]==3:
      return 3;
    else:
      for i in test:
        if i[0,1]==0:#这个时候要把self重新遍历一遍，算隶属度
          Denominator+=float(pow(i[0,0],-2/(Fi-1)))
        else:
          #print('i, i shape ',i,np.shape(i))
          if i[0,1]==1:#注意self这个时候是矩阵，i也是矩阵，i:matrix[[距离,y]]
            AntiGN_Num+=float(pow(i[0,0],-2/(Fi-1)))
            Denominator+=float(pow(i[0,0],-2/(Fi-1)))
          else:
            if i[0,1]==2:
              AntiGP_Num+=float(pow(i[0,0],-2/(Fi-1)))
              Denominator=float(pow(i[0,0],-2/(Fi-1)))
            else:    
              if i[0,1]==3:
                AntiGN_Num+=float(pow(i[0,0],-2/(Fi-1))*0.5)           
                AntiGP_Num+=float(pow(i[0,0],-2/(Fi-1))*0.5)
                Denominator+=float(pow(i[0,0],-2/(Fi-1)))
          #print('GN_Num,GN_Den,GP_Num,GP_Den',[AntiGN_Num,AntiGN_Den,AntiGP_Num,AntiGP_Den])
      if float(AntiGN_Num/Denominator)>float(AntiGP_Num/Denominator):
        return 1
      else:
        return 2
  print("Predict() Error")
           
#利用FKNN进行训练
#XY格式[[1,2,3,4,5,6,y],...]

def FKNN(XY,k,Fi,name):
  XY_train,XY_test=train_test_split(XY)#打乱分组
  Y_test=np.array(XY_test)[:,-1]
  Predictions=[]
  for i in XY_test:  
    List_Dis=Distance(i,XY_train,k)
    Predictions.append(Predict(List_Dis,Fi))
  C_M=confusion_matrix(Y_test,Predictions)
  C_R=classification_report(Y_test,Predictions)
  print(C_M)
  print(C_R)
  print("here is len(X_train)()",len(XY_train))
  try:
    classification_report_csv(C_R,name)
  except:
    print('1 fail')
    return C_M,C_R
  try:
    with open(name,'a') as f:
      f_csv=csv.writer(f)
      f_csv.writerows(C_M)
  except:print('2 fail') 
  return C_M,C_R
 
def classification_report_csv(report,name):
  report_data = []
  lines = report.split('\n')
  for index in [2,3,4,5,7]:#我突然发现可以跳着迭代list，哈哈哈
    row = {}
    row_data = lines[index].split()      
    if index==7:
      row['class']='avg/total'
      row['precision']=float(row_data[3])
      row['recall'] = float(row_data[4])
      row['f1-score'] = float(row_data[5])
      row['support'] = float(row_data[6])
    else:
      row['class'] = row_data[0]
      row['precision'] = float(row_data[1])
      row['recall'] = float(row_data[2])
      row['f1-score'] = float(row_data[3])
      row['support'] = float(row_data[4])
    report_data.append(row)
  dataframe = pd.DataFrame.from_dict(report_data)
  dataframe.to_csv(name, index = False,mode='a')
  
if __name__=='__main__':
  start=time.clock()
  #NameList=['Zero','AntiGN','AntiGP','Two']
 # XY=PrePareData(NameList)
  C_M,C_R=FKNN(data,9,2,'FKNN_PCA_2-0_5-5.csv')#Fi参数一定要大于1
  print('time used:',time.clock()-start)























