Neg:Fin-Die-Neg(265*400)Fin-2-Neg(265*50)PCA_PCM(265*19)1(265*1)

Pos:Fin-Die-Pos(478*400)Fin-2-Pos(478*50)PCA_PCM(478*19)2(478*1)

Zero:Fin-Die-Zero(473*400)Fin-2-Zero(473*50)PCA_PCM(473*19)0(473*1)

Two:Fin-Die-Two(498*400)Fin-2-Zero(498*50)PCA_PCM(498*19)3(498*1)