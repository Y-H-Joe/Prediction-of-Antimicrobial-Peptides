#!/usr/bin/python
import numpy as np
import xgboost as xgb
import pandas as pd
from sklearn.metrics import confusion_matrix,classification_report
import csv,time
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
'''
#先把每个aa的六维理化性质导入
AAindex=pd.read_csv('../PCM_DATA.csv')
#每条多肽链都用六维理化性质表示，长度虽不同都用平均值

def PrePareData(self):
  XY=[];#X装六维理化性质， Y装对应的Label
  for name in self:
    if name=='Zero':y=0;
    else:     
      if name=='AntiGN':y=1;      
      else:
        if name=='AntiGP':y=2;
        else:y=3;
    Name=str('../'+name+'.txt')
    with open(Name) as f:
      for line in f.readlines():
        if (line[0]=='>' or len(line)<4):continue #把AMP序列号和太短的AMP筛除
        line=list(line.strip()) #筛出来的AMP打成一个个氨基酸
        count=0 #count用来计数一条链有几个氨基酸好算平均数
        Indexofline=[0.,0.,0.,0.,0.,0.]# 用来暂时盛放一条多肽链的六维理化性质数据    
        Indexofline2=[]
        for aa in line:
          count+=1
          for i in range(20):
            if aa==AAindex.iloc[i,0]: 
              for j in range(20): Indexofline[j]+=AAindex.iloc[i,j+1]#把每个氨基酸的六维理化性质累加起来
        for i in Indexofline: 
          Indexofline2.append(float(i/count))#list不能操作自己，故转移到另一个list       
        Indexofline2.append(y)
        XY.append(Indexofline2)#XY把理化性质和label打包，使后续training时shuffle split不会乱掉        
  return np.array(XY)
'''

data_T=np.loadtxt("./Data/Fin-Two-2-0_5-5.csv",delimiter=',')
data_P=np.loadtxt("./Data/Fin-Pos-2-0_5-5.csv",delimiter=',')
data_Z=np.loadtxt("./Data/Fin-Zero-2-0_5-5.csv",delimiter=',')
data_N=np.loadtxt("./Data/Fin-Neg-2-0_5-5.csv",delimiter=',')
XY=np.concatenate((data_N,data_P,data_T,data_Z),axis=0)
data_X=XY[:,:-1]
data_X_S=StandardScaler().fit_transform(data_X)
PCA_data_X=PCA(n_components=50).fit_transform(data_X)
data=np.concatenate((PCA_data_X,[[x] for x in XY[:,-1]]),axis=1)

def train(data,name):
  np.random.shuffle(data)
  
  sz = data.shape
  
  train = data[:int(sz[0] * 0.7), :]
  test = data[int(sz[0] * 0.7):, :]
  
  train_X = train[:, :-1]
  train_Y = train[:, -1]
  
  test_X = test[:, :-1]
  test_Y = test[:, -1]
  
  xg_train = xgb.DMatrix(train_X, label=train_Y)
  xg_test = xgb.DMatrix(test_X, label=test_Y)
  # setup parameters for xgboost
  param = {}
  # use softmax multi-class classification
  param['objective'] = 'multi:softmax'
  # scale weight of positive examples
  param['eta'] = 0.1
  param['max_depth'] = 6
  param['silent'] = 1
  param['nthread'] = 4
  param['num_class'] = 4
  
  watchlist = [(xg_train, 'train'), (xg_test, 'test')]
  num_round = 5
  bst = xgb.train(param, xg_train, num_round, watchlist)
  # get prediction
  pred = bst.predict(xg_test)
  error_rate = np.sum(pred != test_Y) / test_Y.shape[0]
  print('Test error using softmax = {}'.format(error_rate))
  Predictions=list(pred)
  Test_Y=list(test_Y)
  C_M=confusion_matrix(Test_Y,Predictions)
  C_R=classification_report(Test_Y,Predictions)
  print(C_M)
  print(C_R)
  try:
    classification_report_csv(C_R,name)
  except:
    print('1 fail')
    return C_M,C_R
  try:
    with open(name,'a') as f:
      f_csv=csv.writer(f)
      f_csv.writerows(C_M)
  except:print('2 fail') 
  return C_M,C_R
  
  # do the same thing again, but output probabilities
  param['objective'] = 'multi:softprob'
  bst = xgb.train(param, xg_train, num_round, watchlist)
  # Note: this convention has been changed since xgboost-unity
  # get prediction, this is in 1D array, need reshape to (ndata, nclass)
  pred_prob = bst.predict(xg_test).reshape(test_Y.shape[0], 4)
  pred_label = np.argmax(pred_prob, axis=1)
  error_rate = np.sum(pred_label != test_Y) / test_Y.shape[0]
  print('Test error using softprob = {}'.format(error_rate))
  
def classification_report_csv(report,name):
  report_data = []
  lines = report.split('\n')
  for index in [2,3,4,5,7]:#我突然发现可以跳着迭代list，哈哈哈
    row = {}
    row_data = lines[index].split()      
    if index==7:
      row['class']='avg/total'
      row['precision']=float(row_data[3])
      row['recall'] = float(row_data[4])
      row['f1-score'] = float(row_data[5])
      row['support'] = float(row_data[6])
    else:
      row['class'] = row_data[0]
      row['precision'] = float(row_data[1])
      row['recall'] = float(row_data[2])
      row['f1-score'] = float(row_data[3])
      row['support'] = float(row_data[4])
    report_data.append(row)
  dataframe = pd.DataFrame.from_dict(report_data)
  dataframe.to_csv(name, index = False,mode='a')

if __name__=='__main__':
  start=time.clock()
  #NameList=['Zero','AntiGN','AntiGP','Two']
  #XY=PrePareData(NameList)
  C_M,C_R=train(data,'XGB_PCA_2-0_5-5.csv')
  print('time used:',time.clock()-start)
