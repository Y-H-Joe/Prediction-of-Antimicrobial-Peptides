# -*- coding: utf-8 -*-
"""
Created on Wed Mar 21 17:10:48 2018

@author: 23712
"""
import numpy as np
from sklearn.ensemble import RandomForestClassifier

def T2_KNN(XY_train,XY_test):
  #计算待测多肽链与训练集中所有多肽链的距离并以[距离，y]的形式返回
  #K条最近的，由小到大排列
  def Distance(test,train,k):
    Dis={}
    for i in train:
      Dis.update({np.linalg.norm(np.array(test[:-1])-np.array(i[:-1])):i[-1]})
    Dis=sorted(Dis.items(),key=lambda i:i[0])
    #排序后选择前k个，格式为[(距离, y),...]
    return Dis[:k]
  
  def KNN(XY_train,XY_test):
    Predictions=[]
    for i in XY_test:  
      List_Dis=Distance(i,XY_train,9)
      Predictions.append(List_Dis[0][1])
    return Predictions
  return KNN(XY_train,XY_test)

def D_KNN (XY_train,XY_test):
  #计算待测多肽链与训练集中所有多肽链的距离并以[距离，y]的形式返回
  #K条最近的，由小到大排列
  def Distance(test,train,k):
    Dis={}
    for i in train:
      Dis.update({np.linalg.norm(np.array(test[:-1])-np.array(i[:-1])):i[-1]})
    Dis=sorted(Dis.items(),key=lambda i:i[0])
    #排序后选择前k个，格式为[(距离, y),...]
    return Dis[:k]
  
  def KNN(XY_train,XY_test):
    Predictions=[]
    for i in XY_test:  
      List_Dis=Distance(i,XY_train,9)
      Predictions.append(List_Dis[0][1])
    return Predictions
  return KNN(XY_train,XY_test)

def D_RF(XY_train,XY_test):
  clf=RandomForestClassifier()
  X_train=[];X_test=[];Y_train=[];Y_test=[];#让train。test有序分组，X，Y的对应顺序不乱
  for xy_train in XY_train:
    X_train.append(xy_train[:-1])
    Y_train.append(xy_train[-1])
  for xy_test in XY_test:
    X_test.append(xy_test[:-1])
    Y_test.append(xy_test[-1])        
  clf.fit(X_train,Y_train)
  Predictions=clf.predict(X_test)
  return list(Predictions)

