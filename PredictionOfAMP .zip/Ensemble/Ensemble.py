# -*- coding: utf-8 -*-
"""
Created on Tue Mar 20 20:47:27 2018

@author: 23712
"""
#模块化设计，每个数据集加学习器的模型算一个文件，所以
#Zero&Three消耗了6个文件，对于这六个文件返回的prediction
#用list比对把Zero和Three给挑出来，剩下的空位由One的三个文
#件返回的prediction填One或Two，再剩下的空位由Zero的三个和One的三个投票填

#Zero	     2&D-KNN	D-RF	
#Three	  PCA_PCM-SVM	PCA_PCM-XG	D-RF  只预测三类，返回 0 1 3
#One	     在上面两个预测出来的基础上进行二分类--D—FKNN&PCA_2-KNN&SVM		
if __name__=='__main__':
  import sys
  sys.path.append('D:\\GoogleDrive\\BiShe\\Pse_Features\\Ensemble')#这里应该搞成相对路径

import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report,confusion_matrix
from sklearn.preprocessing import StandardScaler
import One
import Three
import Zero
from collections import Counter
import csv
import pandas as pd
import itertools

#准备数据
data_T=np.loadtxt("./Data/Fin-Two.csv",delimiter=',')
data_P=np.loadtxt("./Data/Fin-Pos.csv",delimiter=',')
data_Z=np.loadtxt("./Data/Fin-Zero.csv",delimiter=',')
data_N=np.loadtxt("./Data/Fin-Neg.csv",delimiter=',')
XY=np.concatenate((data_N,data_P,data_T,data_Z),axis=0)
data_X=XY[:,:-1]
data_X_S=StandardScaler().fit_transform(data_X)

#PCA_data_X=PCA(n_components=50).fit_transform(data_X)
#PCA_data=np.concatenate((PCA_data_X,[[x] for x in XY[:,-1]]),axis=1)

data=np.concatenate((data_X,[[x] for x in XY[:,-1]]),axis=1)

XY_train,XY_test=train_test_split(data)#打乱分组
#不降维的分解训练测试集
X_train=[];X_test=[];Y_train=[];Y_test=[];#让train。test有序分组，X，Y的对应顺序不乱
for xy_train in XY_train:
  X_train.append(xy_train[:-1])
  Y_train.append(xy_train[-1])
for xy_test in XY_test:
  X_test.append(xy_test[:-1])
  Y_test.append(xy_test[-1]) 
  
'''
#PCA的分解训练测试集

P_X_train=PCA(n_components=50).fit_transform(X_train)
P_X_test=PCA(n_components=50).fit_transform(X_test)
P_Y_train=Y_train
P_Y_test=Y_test
'''

train_2=np.concatenate((XY_train[:,400:450],[[x] for x in XY_train[:,-1]]),axis=1)
test_2=np.concatenate((XY_test[:,400:450],[[x] for x in XY_test[:,-1]]),axis=1)

train_D=np.concatenate((XY_train[:,:400],[[x] for x in XY_train[:,-1]]),axis=1)
test_D=np.concatenate((XY_test[:,:400],[[x] for x in XY_test[:,-1]]),axis=1)

temp=[[x] for x in XY_train[:,-1]] 
temp2=[[1] if x==[2] else x for x in temp]
temp3=[[x] for x in XY_test[:,-1]] 
temp4=[[1] if x==[2] else x for x in temp3]

train_P_PCM=np.concatenate((XY_train[:,450:469],temp2),axis=1)
test_P_PCM=np.concatenate((XY_test[:,450:469],temp4),axis=1)

#Zero	     2&D-KNN	D-RF	
Zero_2_KNN=Zero.T2_KNN(train_2,test_2)
Zero_D_KNN=Zero.D_KNN(train_D,test_D)
Zero_D_RF=Zero.D_RF(train_D,test_D)

#Three	  PCA_PCM-SVM RF D-XG  只预测三类，返回 0 1 3
Three_D_XG=Three.D_XG(train_D,test_D)
Three_P_PCM_SVM=Three.PCA_PCM_SVM(train_P_PCM,test_P_PCM)
Three_P_PCM_RF=Three.PCA_PCM_RF(train_P_PCM,test_P_PCM)

#One	     在上面两个预测出来的基础上进行二分类--D—FKNN& 2-KNN&XG	
One_D_FKNN=One.D_FKNN(train_D,test_D)
One_2_KNN=One.T2_KNN(train_2,test_2)
One_2_XG=One.T2_XG(train_2,test_2)

def TestList_Write(List,name):    
  if set([6]).issubset(set(List)):
    print("List里面有6！")
    
  C_M=confusion_matrix(Y_test,List)
  C_R=classification_report(Y_test,List)
  print(C_M)
  print(C_R)
  try:
    classification_report_csv(C_R,name)
  except:
    print('1 fail')
    return C_M,C_R
  try:
    with open(name,'a') as f:
      f_csv=csv.writer(f)
      f_csv.writerows(C_M)
  except:print('2 fail') 
  return C_M,C_R

def classification_report_csv(report,name):
  report_data = []
  lines = report.split('\n')
  for index in [2,3,4,5,7]:#我突然发现可以跳着迭代list，哈哈哈
    row = {}
    row_data = lines[index].split()      
    if index==7:
      row['class']='avg/total'
      row['precision']=float(row_data[3])
      row['recall'] = float(row_data[4])
      row['f1-score'] = float(row_data[5])
      row['support'] = float(row_data[6])
    else:
      row['class'] = row_data[0]
      row['precision'] = float(row_data[1])
      row['recall'] = float(row_data[2])
      row['f1-score'] = float(row_data[3])
      row['support'] = float(row_data[4])
    report_data.append(row)
  #print('report_data',report_data)
  #print('type report_data',type(report_data))
  dataframe = pd.DataFrame.from_dict(report_data)
  dataframe.to_csv(name, index = False,mode='a')    

List_Model=[Zero_2_KNN,Zero_D_KNN,Zero_D_RF,Three_D_XG,Three_P_PCM_SVM,Three_P_PCM_RF,One_D_FKNN,One_2_KNN,One_2_XG]
 
Predictions=[6 for x in range(len(Zero_2_KNN))]
for i in range(len(Predictions)):
  Predictions[i]=Counter([List_Model[x][i] for x in [6]]).most_common(1)[0][0]
C_R=classification_report(Y_test,Predictions)
C_M=confusion_matrix(Y_test,Predictions)
print(C_R)
print(C_M)
classification_report_csv(C_R,'FKNN.csv')
with open('FKNN.csv','a') as f:
  f_csv=csv.writer(f)
  f_csv.writerows(C_M)

#模块化设计，每个数据集加学习器的模型算一个文件，所以
#Zero&Three消耗了6个文件，对于这六个文件返回的prediction
#用list比对把Zero和Three给挑出来，剩下的空位由One的三个文
#件返回的prediction填One或Two，再剩下的空位由Zero的三个和One的三个投票填
'''
List_Model=[Zero_2_KNN,Zero_D_KNN,Zero_D_RF,Three_D_XG,Three_P_PCM_SVM,Three_P_PCM_RF,One_D_FKNN,One_2_KNN,One_2_XG]
temp_List=[]#用来存放List——Model的所有排练组合元组

#进行排列组合，只考虑C(9,1)到C(9,4)
for i in range(1,10):
  iter=itertools.combinations([x for x in range(9)],i)
  temp_List.append(list(iter))

Predictions=[6 for x in range(len(Zero_2_KNN))]
Score_List=[]
#一层层进入排列组合的组合 
for temp1 in temp_List:#temp1是[(0,1),(1,2),...]
  for temp2 in temp1:#temp2是(0,1)...
    list_Model=[]
    for temp3 in temp2:#temp3是0,1...
      list_Model.append(temp3)
    for i in range(len(Predictions)):
      Predictions[i]=Counter([List_Model[x][i] for x in list_Model]).most_common(1)[0][0]
    C_R=classification_report(Y_test,Predictions)
    Ave_Score=float(C_R.split('\n')[7].split()[5])
    Score_List.append([Ave_Score,temp2])
    
Sorted_Score_List=sorted(Score_List,key=lambda Score:Score[0])
Data=pd.DataFrame(Sorted_Score_List)
Data.to_csv("Fin_Sorted_Score_list.csv",header=None,index=None,mode='a')
'''


