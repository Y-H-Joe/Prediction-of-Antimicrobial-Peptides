# -*- coding: utf-8 -*-
"""
Created on Sat Jan 20 15:43:00 2018

@author: 23712
"""
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report,confusion_matrix
import csv
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA

#先把每个aa的六维理化性质导入
#AAindex=pd.read_csv('../PCA_PCM_DATA.csv')
#每条多肽链都用六维理化性质表示，长度虽不同都用平均值
'''
def PrePareData(self):
  XY=[];#X装六维理化性质， Y装对应的Label
  for name in self:
    if name=='Zero':y=0;
    else:     
      if name=='One':y=1;
      else:y=2;
    Name=str('../'+name+'.txt')
    with open(Name) as f:
      for line in f.readlines():
        if (line[0]=='>' or len(line)<4):continue #把AMP序列号和太短的AMP筛除
        line=list(line.strip()) #筛出来的AMP打成一个个氨基酸
        count=0 #count用来计数一条链有几个氨基酸好算平均数
        Indexofline=[0.,0.,0.,0.,0.,0.]# 用来暂时盛放一条多肽链的六维理化性质数据    
        Indexofline2=[]
        for aa in line:
          count+=1
          for i in range(20):
            if aa==AAindex.iloc[i,0]: 
              for j in range(6): Indexofline[j]+=AAindex.iloc[i,j+1]#把每个氨基酸的六维理化性质累加起来
        for i in Indexofline: 
          Indexofline2.append(float(i/count))#list不能操作自己，故转移到另一个list 
        Indexofline2.append(y)
        XY.append(Indexofline2)#XY把理化性质和label打包，使后续training时shuffle split不会乱掉        
  return XY
'''
data_T=np.loadtxt("./Data/Fin-Two-2-0_5-5.csv",delimiter=',')
data_P=np.loadtxt("./Data/Fin-Pos-2-0_5-5.csv",delimiter=',')
data_Z=np.loadtxt("./Data/Fin-Zero-2-0_5-5.csv",delimiter=',')
data_N=np.loadtxt("./Data/Fin-Neg-2-0_5-5.csv",delimiter=',')
XY=np.concatenate((data_N,data_P,data_T,data_Z),axis=0)
data_X=XY[:,:-1]
data_X_S=StandardScaler().fit_transform(data_X)
PCA_data_X=PCA(n_components=50).fit_transform(data_X)
data=np.concatenate((PCA_data_X,[[x] for x in XY[:,-1]]),axis=1)

'''
def PrePareData(self):
  Num=19
  print(Num)
  XY=[];#X装六维理化性质， Y装对应的Label
  for name in self:
    if name=='Zero':y=0;
    else:     
      if name=='AntiGN':y=1;      
      else:
        if name=='AntiGP':y=2;
        else:y=3;
        
    Name=str(name+'.txt')
    with open(Name) as f:
      for line in f.readlines():
        if (line[0]=='>' or len(line)<4):continue #把AMP序列号和太短的AMP筛除
        line=list(line.strip()) #筛出来的AMP打成一个个氨基酸
        count=0 #count用来计数一条链有几个氨基酸好算平均数
        Indexofline=[0 for x in range(Num)]# 用来暂时盛放一条多肽链的六维理化性质数据    
        Indexofline2=[]
        for aa in line:
          count+=1
          for i in range(20):
            if aa==AAindex.iloc[i,0]: 
              for j in range(Num): Indexofline[j]+=AAindex.iloc[i,j+1]#把每个氨基酸的六维理化性质累加起来
        for i in Indexofline: 
          Indexofline2.append(float(i/count))#list不能操作自己，故转移到另一个list 
        Indexofline2.append(y)
        XY.append(Indexofline2)#XY把理化性质和label打包，使后续training时shuffle split不会乱掉        
  return X
  '''
#计算待测多肽链与训练集中所有多肽链的距离并以[距离，y]的形式返回
#K条最近的，由小到大排列
def Distance(test,train,k):
  Dis={}
  for i in train:
    Dis.update({np.linalg.norm(np.array(test[:-1])-np.array(i[:-1])):i[-1]})
  Dis=sorted(Dis.items(),key=lambda i:i[0])
  #排序后选择前k个，格式为[(距离, y),...]
  return Dis[:k]
 
#利用FKNN进行训练
#XY格式[[1,2,3,4,5,6,y],...]
def FKNN(XY,name):
  XY_train,XY_test=train_test_split(XY)#打乱分组
  Y_test=np.array(XY_test)[:,-1]
  '''
  XY_train=np.array(XY_train);XY_test=np.array(XY_test)
  Mer_XY_train={};Mer_XY_test={}
  for i in XY_train:
    Mer_XY_train={**i,**Mer_XY_train}#这样将{{},{}...}变成了{...}
  for i in XY_test:
    Mer_XY_test={**i,**Mer_XY_test}
  for i in XY_test:#i长[1,2,4,5,6]:0这个样子
    dis=Distance(i,XY_train,9)
  '''
  Predictions=[]
  for i in XY_test:  
    List_Dis=Distance(i,XY_train,9)
    Predictions.append(List_Dis[0][1])
  C_M=confusion_matrix(Y_test,Predictions)
  C_R=classification_report(Y_test,Predictions)
  print(C_M)
  print(C_R)
  print("here is len(X_train)()",len(XY_train))
  try:
    classification_report_csv(C_R,name)
  except:
    print('1 fail')
    return C_M,C_R
  try:
    with open(name,'a') as f:
      f_csv=csv.writer(f)
      f_csv.writerows(C_M)
  except:print('2 fail') 
  return C_M,C_R

def classification_report_csv(report,name):
  report_data = []
  lines = report.split('\n')
  for index in [2,3,4,5,7]:#我突然发现可以跳着迭代list，哈哈哈
    row = {}
    row_data = lines[index].split()      
    if index==7:
      row['class']='avg/total'
      row['precision']=float(row_data[3])
      row['recall'] = float(row_data[4])
      row['f1-score'] = float(row_data[5])
      row['support'] = float(row_data[6])
    else:
      row['class'] = row_data[0]
      row['precision'] = float(row_data[1])
      row['recall'] = float(row_data[2])
      row['f1-score'] = float(row_data[3])
      row['support'] = float(row_data[4])
    report_data.append(row)
  dataframe = pd.DataFrame.from_dict(report_data)
  dataframe.to_csv(name, index = False,mode='a')
  
if __name__=='__main__':
  #NameList=['Zero','AntiGN','AntiGP','Two']
  #XY=PrePareData(NameList)
  C_M,C_R=FKNN(data,'KNN_PCA_2-0_5-5.csv')






















