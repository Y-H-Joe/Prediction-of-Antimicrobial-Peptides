# -*- coding: utf-8 -*-
"""
Created on Wed Mar 21 17:10:48 2018

@author: 23712
"""
import numpy as np
import xgboost as xgb

def D_FKNN(XY_train,XY_test):
  k=9
  Fi=2
  def Predict(test,Fi):
    test=np.matrix(test)#转成矩阵好运算,然后计算+，-性对应的隶属度值哪个高
    Denominator=0;AntiGN_Num=0;
    AntiGP_Num=0;
    if test[0,1]==0:#如果最近的向量抗性为0or2，则无需再预测
      return 0
    else:
      if test[0,1]==3:
        return 3;
      else:
        for i in test:
          if i[0,1]==0:#这个时候要把self重新遍历一遍，算隶属度
            Denominator+=float(pow(i[0,0],-2/(Fi-1)))
          else:
            #print('i, i shape ',i,np.shape(i))
            if i[0,1]==1:#注意self这个时候是矩阵，i也是矩阵，i:matrix[[距离,y]]
              AntiGN_Num+=float(pow(i[0,0],-2/(Fi-1)))
              Denominator+=float(pow(i[0,0],-2/(Fi-1)))
            else:
              if i[0,1]==2:
                AntiGP_Num+=float(pow(i[0,0],-2/(Fi-1)))
                Denominator=float(pow(i[0,0],-2/(Fi-1)))
              else:    
                if i[0,1]==3:
                  AntiGN_Num+=float(pow(i[0,0],-2/(Fi-1))*0.5)           
                  AntiGP_Num+=float(pow(i[0,0],-2/(Fi-1))*0.5)
                  Denominator+=float(pow(i[0,0],-2/(Fi-1)))
            #print('GN_Num,GN_Den,GP_Num,GP_Den',[AntiGN_Num,AntiGN_Den,AntiGP_Num,AntiGP_Den])
        if float(AntiGN_Num/Denominator)>float(AntiGP_Num/Denominator):
          return 1
        else:
          return 2
    print("Predict() Error")

  def Distance(test,train,k):
    Dis={}
    for i in train:
      Dis.update({np.linalg.norm(np.array(test[:-1])-np.array(i[:-1])):i[-1]})
    Dis=sorted(Dis.items(),key=lambda i:i[0])
    return Dis[:k]#排序后选择前k个，格式为[(距离, y),...]

  Predictions=[]
  for i in XY_test:  
    List_Dis=Distance(i,XY_train,k)
    Predictions.append(Predict(List_Dis,Fi))
  return Predictions

def T2_KNN(XY_train,XY_test):
  #计算待测多肽链与训练集中所有多肽链的距离并以[距离，y]的形式返回
  #K条最近的，由小到大排列
  def Distance(test,train,k):
    Dis={}
    for i in train:
      Dis.update({np.linalg.norm(np.array(test[:-1])-np.array(i[:-1])):i[-1]})
    Dis=sorted(Dis.items(),key=lambda i:i[0])
    #排序后选择前k个，格式为[(距离, y),...]
    return Dis[:k]
  
  def KNN(XY_train,XY_test):
    Predictions=[]
    for i in XY_test:  
      List_Dis=Distance(i,XY_train,9)
      Predictions.append(List_Dis[0][1])
    return Predictions
  return KNN(XY_train,XY_test)

def T2_XG(XY_train,XY_test):
  train_X=XY_train[:,:-1];train_Y=XY_train[:,-1];
  test_X=XY_test[:,:-1];test_Y=XY_test[:,-1];
  #要把y label暂时从3转成2，进行xgboost，再将prediction里的2转回3
  temp_train=[2 if x==3 else x for x in train_Y]
  temp_test=[2 if x==3 else x for x in test_Y]
  
  xg_train = xgb.DMatrix(train_X, label=temp_train)
  xg_test = xgb.DMatrix(test_X, label=temp_test)
  # setup parameters for xgboost
  param = {}
  # use softmax multi-class classification
  param['objective'] = 'multi:softmax'
  # scale weight of positive examples
  param['eta'] = 0.1
  param['max_depth'] = 6
  param['silent'] = 1
  param['nthread'] = 4
  param['num_class'] = 4
  
  #watchlist = [(xg_train, 'train'), (xg_test, 'test')]
  num_round = 5
  bst = xgb.train(param, xg_train, num_round)
  # get prediction
  pred = list(bst.predict(xg_test))
  Predicitions=[3 if x==2 else x for x in pred]
  return Predicitions

