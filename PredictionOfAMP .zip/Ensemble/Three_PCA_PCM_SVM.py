# -*- coding: utf-8 -*-
"""
Created on Sat Feb 24 17:02:57 2018

@author: 23712
"""

# -*- coding: utf-8 -*-
"""
Created on Sat Feb 24 15:56:27 2018

@author: 23712
"""
from sklearn import svm
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report,confusion_matrix
#先把每个aa的六维理化性质导入
AAindex=pd.read_csv('../PCM_DATA.csv')
#每条多肽链都用六维理化性质表示，长度虽不同都用平均值
'''
def PrePareData(self):
  Num=73
  XY=[];#X装六维理化性质， Y装对应的Label
  for name in self:
    if name=='Zero':y=0;
    else:     
      if name=='One':y=1;
      else:y=2;
    Name=str('../'+name+'.txt')
    with open(Name) as f:
      for line in f.readlines():
        if (line[0]=='>' or len(line)<4):continue #把AMP序列号和太短的AMP筛除
        line=list(line.strip()) #筛出来的AMP打成一个个氨基酸
        count=0 #count用来计数一条链有几个氨基酸好算平均数
        Indexofline=[0 for x in range(Num)]# 用来暂时盛放一条多肽链的六维理化性质数据    
        Indexofline2=[]
        for aa in line:
          count+=1
          for i in range(20):
            if aa==AAindex.iloc[i,0]: 
              for j in range(Num): Indexofline[j]+=AAindex.iloc[i,j+1]#把每个氨基酸的六维理化性质累加起来
        for i in Indexofline: 
          Indexofline2.append(float(i/count))#list不能操作自己，故转移到另一个list 
        XY.append([Indexofline2,y])#XY把理化性质和label打包，使后续training时shuffle split不会乱掉        
  return XY
'''

def PrePareData(self):
  Num=19
  print(Num)
  XY=[];#X装六维理化性质， Y装对应的Label
  for name in self:
    if name=='Zero':y=0;
    else:     
      if name=='One':y=1;
      else:y=2;
    Name=str(name+'.txt')
    with open(Name) as f:
      for line in f.readlines():
        if (line[0]=='>' or len(line)<4):continue #把AMP序列号和太短的AMP筛除
        line=list(line.strip()) #筛出来的AMP打成一个个氨基酸
        count=0 #count用来计数一条链有几个氨基酸好算平均数
        Indexofline=[0 for x in range(Num)]# 用来暂时盛放一条多肽链的六维理化性质数据    
        Indexofline2=[]
        for aa in line:
          count+=1
          for i in range(20):
            if aa==AAindex.iloc[i,0]: 
              for j in range(Num): Indexofline[j]+=AAindex.iloc[i,j+1]#把每个氨基酸的六维理化性质累加起来
        for i in Indexofline: 
          Indexofline2.append(float(i/count))#list不能操作自己，故转移到另一个list 
        XY.append([Indexofline2,y])#XY把理化性质和label打包，使后续training时shuffle split不会乱掉        
  return XY
#利用sklearn.MLPClassification进行训练
def SVMTraining(XY):
  XY_train,XY_test=train_test_split(XY)#打乱分组
  clf=svm.SVC()
  X_train=[];X_test=[];Y_train=[];Y_test=[];#让train。test有序分组，X，Y的对应顺序不乱
  for xy_train in XY_train:
    X_train.append(xy_train[0])
    Y_train.append(xy_train[1])
  for xy_test in XY_test:
    X_test.append(xy_test[0])
    Y_test.append(xy_test[1])
  clf.fit(X_train,Y_train)
  predictions=clf.predict(X_test)
  print(confusion_matrix(Y_test,predictions))
  print(classification_report(Y_test,predictions))
  print("here is len(X_train)()",len(X_train))
  print("here is support vectors:",clf.support_vectors_)
  
  
  
if __name__=='__main__':
  NameList=['Zero','One','Two']
  XY=PrePareData(NameList)
  SVMTraining(XY)














