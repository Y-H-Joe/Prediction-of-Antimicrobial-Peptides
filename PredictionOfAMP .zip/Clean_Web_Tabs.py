# -*- coding: utf-8 -*-
"""
Created on Thu Mar 15 15:21:06 2018

@author: 23712
"""
import pandas as pd
import numpy as np
'''
def Type(name):
    data=pd.read_csv(str(name+'-2-0_5-5.csv'),header=None)
    List=[]
    List2=[]
    Index=[0,1,2,3,4,5,6,7]
    try:
        for i in range(0,data.index[-1]+1,8):
            data_part=data.loc[i:i+7]
            data_part.index=Index
            for row in range(2,7):
                for col in range(10):
                    List.append(float(data_part[col][row]))
            List.append(2)
            List2.append(List)
            List=[]
    except:
        pass
    File=pd.DataFrame(List2)
    File.to_csv(str('Fin-'+name+'-2-0_5-5.csv'),index=None)
'''    
'''
def main(row_num,label):
    #data=pd.read_csv(str('./Data/'+Type+'-'+name+"-"+w+".csv"),header=None)
    data=pd.read_csv("./Data/Zero-2-0_5-5.csv",header=None)
    List=[]
    List2=[]
    Index=[x for x in range(row_num)]    
    try:
        for i in range(0,data.index[-1]+1,row_num):
            data_part=data.loc[i:i+row_num-1]
            data_part.index=Index
            for row in range(2,row_num-2):
                for col in range(data_part.shape[1]):
                    List.append(float(data_part[col][row]))
            List.append(label)
            List2.append(List)
            List=[]
    except:
        pass
    File=pd.DataFrame(List2)
    File.to_csv("Fin-Zero-2-0_5-5.csv",index=None)
'''
'''
    try:
      File.to_csv(str('Fin-'+name+'-'+Type+L+w+'.csv'),index=None)
    except:
      File.to_csv(str('Fin-'+name+'-'+Type+w+'.csv'),index=None)
'''
row_num=8
label=3
data=pd.read_csv("./Data/Two-2-0_5-5.csv",header=None)
List=[]
List2=[]
Index=[x for x in range(row_num)]    
try:
    for i in range(0,data.index[-1]+1,row_num):
        data_part=data.loc[i:i+row_num-1]
        data_part.index=Index
        for row in range(2,row_num-1):
            for col in range(data_part.shape[1]):
                List.append(float(data_part[col][row]))
        List.append(label)
        List2.append(List)
        List=[]
except:
    pass
File=pd.DataFrame(List2)
File.to_csv("Fin-Two-2-0_5-5.csv",index=None)    
      
