# -*- coding: utf-8 -*-
"""
Created on Sat Mar 17 15:52:51 2018

@author: 23712
"""
import pandas as pd
import numpy as np

data_T=np.loadtxt("Fin-Die-Two-0_5.csv",delimiter=',')
data_P=np.loadtxt("Fin-Die-Pos-0_5.csv",delimiter=',')
data_Z=np.loadtxt("Fin-Die-Zero-0_5.csv",delimiter=',')
data_N=np.loadtxt("Fin-Die-Neg-0_5.csv",delimiter=',')
XY=np.concatenate((data_N,data_P,data_T,data_Z),axis=0)



