# -*- coding: utf-8 -*-
"""
Created on Wed Feb 28 12:21:56 2018

@author: 23712
"""

from sklearn.naive_bayes import GaussianNB
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report,confusion_matrix
import csv
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
import numpy as np
'''
#先把每个aa的六维理化性质导入
AAindex=pd.read_csv('../PCA_PCM_DATA.csv')
#每条多肽链都用六维理化性质表示，长度虽不同都用平均值

class SeqPre(object):
  def __init__(self,name):

def PrePareData(self):
  Num=19
  print(Num)
  XY=[];#X装六维理化性质， Y装对应的Label
  for name in self:
    if name=='Zero':y=0;
    else:     
      if name=='AntiGN':y=1;
      else:
        if name=='AntiGP':y=2;
        else:y=3
    Name=str(name+'.txt')
    with open(Name) as f:
      for line in f.readlines():
        if (line[0]=='>' or len(line)<4):continue #把AMP序列号和太短的AMP筛除
        line=list(line.strip()) #筛出来的AMP打成一个个氨基酸
        count=0 #count用来计数一条链有几个氨基酸好算平均数
        Indexofline=[0 for x in range(Num)]# 用来暂时盛放一条多肽链的六维理化性质数据    
        Indexofline2=[]
        for aa in line:
          count+=1
          for i in range(20):
            if aa==AAindex.iloc[i,0]: 
              for j in range(Num): Indexofline[j]+=AAindex.iloc[i,j+1]#把每个氨基酸的六维理化性质累加起来
        for i in Indexofline: 
          Indexofline2.append(float(i/count))#list不能操作自己，故转移到另一个list 
        XY.append([Indexofline2,y])#XY把理化性质和label打包，使后续training时shuffle split不会乱掉        
  return XY
'''
data_T=np.loadtxt("./Data/Fin-Two-2-0_5-5.csv",delimiter=',')
data_P=np.loadtxt("./Data/Fin-Pos-2-0_5-5.csv",delimiter=',')
data_Z=np.loadtxt("./Data/Fin-Zero-2-0_5-5.csv",delimiter=',')
data_N=np.loadtxt("./Data/Fin-Neg-2-0_5-5.csv",delimiter=',')
XY=np.concatenate((data_N,data_P,data_T,data_Z),axis=0)
data_X=XY[:,:-1]
data_X_S=StandardScaler().fit_transform(data_X)
PCA_data_X=PCA(n_components=50).fit_transform(data_X)
data=np.concatenate((PCA_data_X,[[x] for x in XY[:,-1]]),axis=1)

def GNB(XY,name):
  XY_train,XY_test=train_test_split(XY)#打乱分组
  clf=GaussianNB()
  X_train=[];X_test=[];Y_train=[];Y_test=[];#让train。test有序分组，X，Y的对应顺序不乱
  for xy_train in XY_train:
    X_train.append(xy_train[:-1])
    Y_train.append(xy_train[-1])
  for xy_test in XY_test:
    X_test.append(xy_test[:-1])
    Y_test.append(xy_test[-1]) 
  clf.fit(X_train,Y_train)
  Predictions=clf.predict(X_test)
  C_M=confusion_matrix(Y_test,Predictions)
  C_R=classification_report(Y_test,Predictions)
  print(C_M)
  print(C_R)
  print("here is len(X_train)()",len(XY_train))
  try:
    classification_report_csv(C_R,name)
  except:
    print('1 fail')
    return C_M,C_R
  try:
    with open(name,'a') as f:
      f_csv=csv.writer(f)
      f_csv.writerows(C_M)
  except:print('2 fail') 
  return C_M,C_R

def classification_report_csv(report,name):
  report_data = []
  lines = report.split('\n')
  for index in [2,3,4,5,7]:#我突然发现可以跳着迭代list，哈哈哈
    row = {}
    row_data = lines[index].split()      
    if index==7:
      row['class']='avg/total'
      row['precision']=float(row_data[3])
      row['recall'] = float(row_data[4])
      row['f1-score'] = float(row_data[5])
      row['support'] = float(row_data[6])
    else:
      row['class'] = row_data[0]
      row['precision'] = float(row_data[1])
      row['recall'] = float(row_data[2])
      row['f1-score'] = float(row_data[3])
      row['support'] = float(row_data[4])
    report_data.append(row)
  print('report_data',report_data)
  print('type report_data',type(report_data))
  dataframe = pd.DataFrame.from_dict(report_data)
  dataframe.to_csv(name, index = False,mode='a')  
  
  
  
if __name__=='__main__':
  #NameList=['Zero','AntiGN','AntiGP','Two']
  #XY=PrePareData(NameList)
  GNB(XY,'NB_PCA_2-0_5-5.csv')