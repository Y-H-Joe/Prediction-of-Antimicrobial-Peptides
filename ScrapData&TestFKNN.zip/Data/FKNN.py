# -*- coding: utf-8 -*-
"""
Created on Tue Sep  5 15:55:03 2017

@author: 23712
"""
Name=['antifungal','antiHIV','Antimalarial','Antioxidant','antiparasitic','antiviral','cancercells','Chemotactic','GramNList','GramPList','GramPNList','Insecticidal','proteaseI','Spermicidal','Surfaceimm','WoundH','MammalianCells']

def FindTrueLabel(name):#把某个AP的活性类别按照list返回
  with open("CleanActOfAllAPD.txt","r") as f:
    for i in f.readlines():
      i=i.strip()
      i=eval(i)
      if(i[0]==name):
        TrueLabel=eval(i[1])
  return TrueLabel


def Distance(a,b):#需要输入两个列表
  tem=sum((x-y)**2 for x,y in zip(a,b))
  if(tem)==0:
    return 0
  else:
    return tem**(-6.66666667)#返回距离，是个数值
      
APDname=[]#装测试集中各个待测AP的AP值
VecTested=[]

#打开一个测试集，提取里面的AP值输入到APDname,180维值输入VecTested
with open('./TestSet/180DGramPList.txt','r') as f:
  for line in f.readlines():
    line=line.strip()
    if(line[0:1]=='>'):
      APDname.append(line)
      continue
    line=eval(line)
    VecTested.append(line)
  #在APDname中调用一个AP,再在VecTested中调用一个180，进行运算和预测 
  APandV=[]#集合待测待测AP与各个抗性的测试集的[[抗性名称，该抗性下的隶属度值]...]
  FenMuofAcu=len(APDname)#正确率的分母，是测试集中AP的数量
  FenZiofAcu=0#正确率的分子，表示有几个是预测正确的
  NotStricFenZi=0#如果被预测的东西包含了，也算正确
  test=0
  for count in range(len(APDname)):#count是APDname&VecTested的计数器,循环APDname里的每一个AP
    ListofAll=[]#ListofAll是按照[[AP,distance]...]来集合所有类别的训练集中与待测AP距离前9的
    for X in Name:
      name=str("./TrainSet/180D"+X+".txt")  
      DisList=[]#name抗性trainset里各个AP对待测向量的距离，顺序要与APDList一致
      APDList=[]#APDList里面装name抗性train set的所有AP值
      ListofNine=[]
      PartListofAll=[]
      with open(name,'r') as f:#打开name抗性的train set
        for i in f.readlines():
          i=i.strip()
          if(i[0:1]=='>'):
            APDList.append(i)#APDList里面装name抗性train set的所有AP值
            continue
          EvalI=eval(i)#name抗性train set里第i个AP的180维向量
          if(Distance(EvalI,VecTested[count])==0):
            continue
          else:
            DisList.append(Distance(EvalI,VecTested[count]))#把待测AP与训练集各个向量的距离算出来并加入DisList中          
      DictofAll=dict(zip(APDList,DisList))#混合APDList和DistList的字典，键值对
      for i in sorted(DictofAll,key=DictofAll.get):
        PartListofAll.append([i,DictofAll[i]])#PartListofAll包括[AP,distance]，是排序过后的DicofAll，是列表
      for i in range(9):
        ListofNine.append(PartListofAll[i])#ListofNine 包括[AP,distance]，是选取PartListofAll的前九个的列表
      del(PartListofAll)
      ListofAll+=ListofNine#ListofAll[[AP,dis]...]也是包括了两项的，它将包括所有类别的训练集中与待测AP距离前9的列表
      SumFenMu=0
      SumFenzi=0
      for i in ListofNine:
        SumFenMu+=i[1]#分母九个距离和算出来了，接下来算分子
      for i in ListofNine:
        TrueLabel=FindTrueLabel(i[0])#把九个中的一个的活性种类按照列表返回
        v0=(1/len(TrueLabel))#算出来九个中的一个的隶属度值，就是活性种类分之一
        SumFenzi+=v0*i[1]#循环结束，SumFenzi就是分子的求和了
      v1=SumFenzi/SumFenMu#v1就是待测向量在名叫name这个类别的trainset里的隶属度值
      if(X=='antifungal'):
        temp='antifungal'
      if(X=='antiHIV'):
        temp='anti-HIV'
      if(X=='Antimalarial'):
        temp='Antimalarial'
      if(X=='Antioxidant'):
        temp='Antioxidant'
      if(X=='antiparasitic'):
        temp='antiparasitic'
      if(X=='antiviral'):
        temp='antiviral'
      if(X=='cancercells'):
        temp=='Cancer cells'
      if(X=='Chemotactic'):
        temp="Chemotactic"
      if(X=="GramNList"):
        temp='anti-Gram-'
      if(X=='GramPList'):
        temp='anti-Gram+'
      if(X=='GramPNList'):
        temp='anti-Gram+ & Gram-'
      if(X=='Insecticidal'):
        temp="Insecticidal"
      if(X=='proteaseI'):
        temp="Enzyme inhibitor"
      if(X=='Spermicidal'):
        temp="Spermicidal"
      if(X=='Surfaceimm'):
        temp="Surface immobilized AMPs"
      if(X=='WoundH'):
        temp="wound healing"
      if(X=='MammalianCells'):
        temp="Mammalian cells"
      APandV.append([temp,v1])#把[抗性名称，该抗性下的隶属度值]加入列表APandV中
    #利用得到的ListofAll与APandV，来对待测AP进行预测
    #首先求待测AP有几个抗性，看谁离待测AP最近
    tem=ListofAll[0]
    for i in ListofAll:#运用一个for loop把最近的赋给了tem=[AP,distance]
      if(i[1]<tem[1]):
        tem=i
        
    NumTrueLabel=len(FindTrueLabel(tem[0]))#NumTrueLabel即为待测AP的抗性数目
    #print("This is FindTrueLable(tem[0]): ",FindTrueLabel(tem[0]))
    APandV.sort(key=lambda APandV:APandV[1],reverse=True)#把APandV的隶属度值按照从高到低排列
    Z=[]#Z表示被测AP所具有的活性类别，是个列表
    for i in range(NumTrueLabel):
      Z.append(APandV[i][0])
    TrueL=FindTrueLabel(APDname[count])
    if(Z==TrueL):
      FenZiofAcu+=1
    if(not set(Z).difference(TrueL)):
      NotStricFenZi+=1
    APandV=[]
    test+=1
  print("accuracy is: ",FenZiofAcu/FenMuofAcu)
  print("not strict accuracy is: ",NotStricFenZi/FenMuofAcu)
  print("test is ",test)
    
      

  
      

'''   
with open('./TestSet/180Dantifungal.txt','r') as f:
  for i in f.readlines():
    i=i.strip()
    if(i[0:1]=='>'):
      globals()["APbeingTested"]=i#APbeingtested 为一类抗性测试文件中所有被测试的AP值
      continue
    globals()["TestedVec"]=eval(i)#TestedVec 为一类抗性测试文件中所有被测试向量的180维数据
'''
'''
ListofAll=[]#ListofAll是按照[[AP,distance]...]来集合所有类别的训练集中与待测AP距离前9的
APandV=[]#集合待测待测AP与各个抗性的测试集的[[抗性名称，该抗性下的隶属度值]...]

        
for X in Name:
  name=str("./TrainSet/180D"+X+".txt")  
  DisList=[]#name抗性trainset里各个AP对待测向量的距离，顺序要与APDList一致
  APDList=[]#APDList里面装name抗性train set的所有AP值
  ListofNine=[]
  PartListofAll=[]
  with open(name,'r') as f:#打开name抗性的train set
    for i in f.readlines():
      i=i.strip()
      if(i[0:1]=='>'):
        APDList.append(i)#APDList里面装name抗性train set的所有AP值
        continue
      EvalI=eval(i)#name抗性train set里第i个AP的180维向量
      DisList.append(Distance(EvalI,VecTested))#把待测AP与训练集各个向量的距离算出来并加入DisList中
  DictofAll=dict(zip(APDList,DisList))#混合APDList和DistList的字典，键值对
  for i in sorted(DictofAll,key=DictofAll.get):
    PartListofAll.append([i,DictofAll[i]])#PartListofAll包括[AP,distance]，是排序过后的DicofAll，是列表
  for i in range(9):
    ListofNine.append(PartListofAll[i])#ListofNine 包括[AP,distance]，是选取PartListofAll的前九个的列表
  del(PartListofAll)
  ListofAll+=ListofNine#ListofAll[[AP,dis]...]也是包括了两项的，它将包括所有类别的训练集中与待测AP距离前9的列表
  SumFenMu=0
  SumFenzi=0
  for i in ListofNine:
    SumFenMu+=i[1]#分母九个距离和算出来了，接下来算分子
  for i in ListofNine:
    TrueLabel=FindTrueLabel(i[0])#把九个中的一个的活性种类按照列表返回
    v0=(1/len(TrueLabel))#算出来九个中的一个的隶属度值，就是活性种类分之一
    SumFenzi+=v0*i[1]#循环结束，SumFenzi就是分子的求和了
  v1=SumFenzi/SumFenMu#v1就是待测向量在名叫name这个类别的trainset里的隶属度值
  APandV.append([X,v1])#把[抗性名称，该抗性下的隶属度值]加入列表APandV中
  
#利用得到的ListofAll与APandV，来对待测AP进行预测
#首先求待测AP有几个抗性，看谁离待测AP最近
tem=ListofAll[0]
for i in ListofAll:#运用一个for loop把最近的赋给了tem=[AP,distance]
  if(i[1]<tem[1]):
    tem=i
    
NumTrueLabel=len(FindTrueLabel(tem[0]))#NumTrueLabel即为待测AP的抗性数目
APandV.sort(key=lambda APandV:APandV[1],reverse=True)#把APandV的隶属度值按照从高到低排列
for i in range(NumTrueLabel):
  print(APandV[i][0])

'''
  

    
    
   
      
      
      