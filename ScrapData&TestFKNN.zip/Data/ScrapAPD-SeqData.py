# -*- coding: utf-8 -*-
"""
Created on Fri Sep  1 12:26:16 2017

@author: 23712
"""
from urllib.request import urlopen
from bs4 import BeautifulSoup
from urllib.error import HTTPError

GramPList=[]
GramNList=[]
GramPNList=[]
antiviral=[]
cancercells=[]
antiHIV=[]
antifungal=[]
antiprotists=[]
antiparasitic=[]
Antimalarial=[]
Insecticidal=[]
Spermicidal=[]
Chemotactic=[]
Surfaceimm=[]
proteaseI=[]
WoundH=[]
Antioxidant=[]
MammalianCells=[]

HOLE=[antifungal,antiHIV,Antimalarial,Antioxidant,antiparasitic,antiprotists,antiviral,cancercells,Chemotactic,GramNList,GramPList,GramPNList,Insecticidal,proteaseI,Spermicidal,Surfaceimm,WoundH,MammalianCells]

def getID(url):
  try:
    html=urlopen(url)
  except HTTPError as e:
    print("here is HTTPError")
    return None
  try:
    bsObj=BeautifulSoup(html,"html.parser")
    List=bsObj.findAll("td",{"width":"21%"})
    countAPD=0;countAct=0;countSeq=0;count=0;
    index=0
    while index!=2:
      if(List[count].get_text()=='APD ID:'):
        countAPD=count        
      elif(List[count].get_text()=='Activity:'):
        countAct=count
        index+=1
      elif(List[count].get_text()=='Sequence:'):
        countSeq=count
        index+=1
      count+=1
    return [List,countAct,countSeq,countAPD]
  except AttributeError as e:
    print("here is AttributeError")
    return None
  
def Main(i):
  url=str("http://aps.unmc.edu/AP/database/query_output.php?ID=0"+str(i))
  [List,countAct,countSeq,countAPD]=getID(url)
  if List==None:
    print("ID can't be found")
  else:
    APD=List[countAPD].parent.find("td",{"width":"61%"}).get_text()
    FastaAPD=str('>'+APD)
    print(FastaAPD)
    
    Actx=List[countAct].parent.find("td",{"width":"61%"}).get_text()
    Seq=List[countSeq].parent.find("td",{"width":"61%"}).get_text()
    print(Seq)
       
    ActListx=[ele for ele in Actx.split(',') if len(ele)>2]
    ActList=[]
    for i in ActListx:
      ActList.append(i.strip())
    print(ActList)
    del(ActListx)
  
    try:
      for i in  ActList:
        if(i=='anti-Gram+ & Gram-'):
          GramPNList.append(FastaAPD)
          GramPNList.append(Seq)
        if(i=='antiviral'):
          antiviral.append(FastaAPD)
          antiviral.append(Seq)
        if(i=='Cancer cells'):
          cancercells.append(FastaAPD)
          cancercells.append(Seq)
        if(i=='anti-HIV'):
          antiHIV.append(FastaAPD)
          antiHIV.append(Seq)
        if(i=="antifungal"):        
          antifungal.append(FastaAPD)
          antifungal.append(Seq)
        if(i=='anti-Gram+'):          
          GramPList.append(FastaAPD)
          GramPList.append(Seq)
        if(i=='anti-Gram-'):
          GramNList.append(FastaAPD)          
          GramNList.append(Seq)
        if(i=="anti-protists"):
          antiprotists.append(FastaAPD)          
          antiprotists.append(Seq)
        if(i=="antiparasitic"):
          antiparasitic.append(FastaAPD)          
          antiparasitic.append(Seq)
        if(i=="Antimalarial"):
          Antimalarial.append(FastaAPD)          
          Antimalarial.append(Seq)
        if(i=="Insecticidal"):
          Insecticidal.append(FastaAPD)         
          Insecticidal.append(Seq)
        if(i=="Spermicidal"):
          Spermicidal.append(FastaAPD)
          Spermicidal.append(Seq)
        if(i=="Chemotactic"):
          Chemotactic.append(FastaAPD)
          Chemotactic.append(Seq)
        if(i=="Surface immobilized AMPs"):
          Surfaceimm.append(FastaAPD)
          Surfaceimm.append(Seq)
        if(i=="Enzyme inhibitor"):
          proteaseI.append(FastaAPD)
          proteaseI.append(Seq)
        if(i=="wound healing"):        
          WoundH.append(FastaAPD)
          WoundH.append(Seq)
        if(i=="Antioxidant"):         
          Antioxidant.append(FastaAPD)
          Antioxidant.append(Seq)
        if(i=="Mammalian cells"):        
          MammalianCells.append(FastaAPD)
          MammalianCells.append(Seq)
       
    except AttributeError as e:
      print("something wrong when add seq into list")

def ToWrite(name,count):
  TextName=str(name+".txt")
  try:
    file=open(TextName,"w") 
    for i in HOLE[count]:
      file.write(str(i))
      file.write('\n')
  except AttributeError as e:
    print("problem in ToWrite write e",count)
  finally:
    file.close()
  
Name=['antifungal','antiHIV','Antimalarial','Antioxidant','antiparasitic','antiprotists','antiviral','cancercells','Chemotactic','GramNList','GramPList','GramPNList','Insecticidal','proteaseI','Spermicidal','Surfaceimm','WoundH','MammalianCells']

  
for i in range(1,2902):
  tem=str(10000+i)
  tem=tem[1:]
  Main(tem)

count=0
for i in Name:
  ToWrite(i,count)
  count+=1

  
  
  
  

    






