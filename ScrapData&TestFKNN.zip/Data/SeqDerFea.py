# -*- coding: utf-8 -*-
"""
Created on Sun Sep  3 20:41:21 2017

@author: 23712
"""
import numpy as np

 
ALLName=['antifungal','antiHIV','Antimalarial','Antioxidant','antiparasitic','antiprotists','antiviral','cancercells','Chemotactic','GramNList','GramPList','GramPNList','Insecticidal','proteaseI','Spermicidal','Surfaceimm','WoundH','MammalianCells']


def GetPCM(Try):
  pcA=[0.636250473,-0.151878012,-1.591936402,0.796583001,0.789208337,-0.106023993]
  pcC=[0.297601028,-0.418330663,-0.529538803,-2.331104856,2.635428353,-0.660298108]
  pcD=[-0.923589397,1.713290552,-0.131139704,-1.500312769,0.241428771,-1.697655166]
  pcE=[-0.759395726,1.713290552,0.333659246,0.014661037,0.383445696,-1.64680433]
  pcF=[1.221190425,-1.217688619,0.931257895,1.920595825,-0.488943982,-0.207725666]
  pcG=[0.492581012,0.11457464,-2.056735352,0.747712878,0.241428771,-0.131449412]
  pcH=[-0.410484176,-0.151878012,0.632458571,-1.989013996,-1.036723548,0.6719938]
  pcI=[1.416170408,-0.844654907,-0.197539554,0.649972633,0.566038884,-0.141619579]
  pcK=[-1.539315661,1.713290552,0.333659246,0.06353116,-1.178740472,1.602564103]
  pcL=[1.087783067,-0.844654907,-0.197539554,0.845453124,0.241428771,-0.141619579]
  pcM=[0.656774682,-0.578202255,0.400059096,0.454492142,-0.549808379,-0.294172087]
  pcN=[-0.800444144,0.221155701,-0.164339629,-0.034209086,-0.793265963,2.258539889]
  pcP=[0.123145253,0.11457464,-0.695538428,-0.962741418,2.270241977,-0.009407405]
  pcQ=[-0.872278875,0.221155701,0.300459321,-0.083079209,-0.712113435,-0.33993784]
  pcR=[-2.596312415,1.713290552,1.263257145,-0.034209086,-0.793265963,2.258539889]
  pcS=[-0.184717879,0.274446231,-1.060737603,0.112401282,-0.671537171,-0.324682589]
  pcT=[-0.051310522,-0.098587481,-0.595938653,-0.180819454,-0.732401567,-0.365363258]
  pcV=[1.108307276,-0.684783315,-0.662338503,0.503362264,0.52546262,-0.151789746]
  pcW=[0.831230457,-1.697303393,2.226054969,0.943193369,-0.184622002,-0.222980917]
  pcY=[0.266814715,-1.111107558,1.462456695,0.06353116,-0.752689699,-0.350108007]
  
  Name=str(Try+'.txt')
  scrapName=str('./ScrapData/'+Try+'.txt')
  file=open(scrapName,'r')
  PCL=[]
  APD=[]
  for line in file:
    if(line[0:1]=='>'):
      APD.append(line)
    else:
      if(len(line)>4):
        PCL.append(line)
  index=0
  for i in PCL:
    tem1=list(i)
    tem2=[]
    count=0
    for l in tem1:
      count+=1
      if(l=='A'):
        tem2.append(pcA)
        continue
      if(l=='C'):
        tem2.append(pcC)
        continue
      if(l=='D'):
        tem2.append(pcD)
        continue
      if(l=='E'):
        tem2.append(pcE)
        continue
      if(l=='F'):
        tem2.append(pcF)
        continue
      if(l=='G'):
        tem2.append(pcG)
        continue
      if(l=='H'):
        tem2.append(pcH)
        continue
      if(l=='I'):
        tem2.append(pcI)
        continue
      if(l=='K'):
        tem2.append(pcK)
        continue
      if(l=='L'):
        tem2.append(pcL)
        continue
      if(l=='M'):
        tem2.append(pcM)
        continue
      if(l=='N'):
        tem2.append(pcN)
        continue
      if(l=='P'):
        tem2.append(pcP)
        continue
      if(l=='Q'):
        tem2.append(pcQ)
        continue
      if(l=='R'):
        tem2.append(pcR)
        continue
      if(l=='S'):
        tem2.append(pcS)
        continue
      if(l=='T'):
        tem2.append(pcT)
        continue
      if(l=='V'):
        tem2.append(pcV)
        continue
      if(l=='W'):
        tem2.append(pcW)
        continue
      if(l=='Y'):
        tem2.append(pcY)
        continue
    #locals()['Seq'+str(index)]=tem2
    try: 
      pcmNAME=str('pcm-'+Name)
      with open(pcmNAME,'a') as e:
        e.write(APD[index])
        e.write(str(tem2))
        e.write('\n')
    except AttributeError as e:
      print("error when write into file")
    index+=1

def AC(line):
  tem=[]
  mean=np.average(line,axis=1)
  L=line.shape[1]
  for i in range(6):
    for lg in range(1,6):
      Sum=0
      for j in range(L-lg):
        Sum+=(line[i,j]-mean[i])*(line[i,j+lg]-mean[i])/(L-lg)
      tem.append(Sum)
  tem1=[]
  #print("tem is ",tem)
  for i in tem:
    #print(i)
    if(type(i)!=int):
      i=i.tolist()
      i=i[0]
      tem1=tem1+i
    else:
      tem1.append(i)
  return tem1

def CC(line):
  tem=[]
  mean=np.average(line,axis=1)
  L=line.shape[1]
  for i1 in range(6):
    for i2 in range(6):
      if i1==i2:
        continue
      for lg in range(1,6):
        Sum=0
        for j in range(L-lg):
          Sum+=(line[i1,j]-mean[i1])*(line[i2,j+lg]-mean[i2])/(L-lg)
        tem.append(Sum)
  tem1=[]
  for i in tem:
    if(type(i)!=int):
      i=i.tolist()
      i=i[0]
      tem1=tem1+i
    else:
      tem1.append(i)
  return tem1

for name in ALLName:
  try:
    GetPCM(name)
  except AttributeError as e:
    print("error when GetPCM(name)")  

for name in ALLName:
  CalName=str('pcm-'+name+'.txt')
  APD=[]
  tem=[]
  PCL=[]
  PACC1=[]
  PACC=[]
  with open(CalName) as f:
    try:
      for line in f:
        if(line[0:1]=='>'):
          APD.append(line.strip())
          continue
        y=line.strip()
        x=eval(y)
        tem.append(x)
    except AttributeError as e:
      print("1 for")
    
    for line in tem:
      line=np.mat(line)
      line=line.T
      tem2=[]
      tem2=AC(line)+CC(line)
      PACC1.append(tem2)
    count=0
    #print("tem is ",tem)
    #print("PACC1 is ",PACC1)
    #print("APD is ",APD)
    
    try:
      for line in APD:
        PACC.append(line)
        PACC.append(PACC1[count])
        count+=1
    except AttributeError as e:
      print("3 for")
  
  OutPutName=str('180D'+name+'.txt')
  try:
    with open(OutPutName,'a') as e:
      for line in PACC:
        #print("*****",line,"******")
        line=str(line)
        e.write(line)
        e.write('\n')
  except AttributeError as e:
    print("Error when we finally write into docs")

        
        





