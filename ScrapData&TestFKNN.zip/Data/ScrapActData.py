# -*- coding: utf-8 -*-
"""
Created on Tue Sep  5 09:41:07 2017

@author: 23712
"""
from urllib.request import urlopen
from bs4 import BeautifulSoup
from urllib.error import HTTPError

def getID(url):
  try:
    html=urlopen(url)
  except HTTPError as e:
    print("here is HTTPError")
    return None
  try:
    bsObj=BeautifulSoup(html,"html.parser")
    List=bsObj.findAll("td",{"width":"21%"})
    countAPD=0;countAct=0;count=0;
    index=0
    while index!=1:
      if(List[count].get_text()=='APD ID:'):
        countAPD=count        
      elif(List[count].get_text()=='Activity:'):
        countAct=count
        index+=1
      count+=1
    return [List,countAct,countAPD]
  except AttributeError as e:
    print("here is AttributeError")
    return None

  
def Main(i):
  url=str("http://aps.unmc.edu/AP/database/query_output.php?ID=0"+str(i))
  [List,countAct,countAPD]=getID(url)
  if List==None:
    print("ID can't be found")
  else:
    APD=List[countAPD].parent.find("td",{"width":"61%"}).get_text()
    FastaAPD=str('>'+APD)
    print(FastaAPD)
    
    Actx=List[countAct].parent.find("td",{"width":"61%"}).get_text()
       
    ActListx=[ele for ele in Actx.split(',') if len(ele)>2]
    ActList=[]
    for i in ActListx:
      ActList.append(i.strip())
    print(ActList)
    del(ActListx)
  return [FastaAPD,ActList]


def ToWrite(APD,ActList,name):
  TextName=str(name+".txt")
  try:
    file=open(TextName,"a") 
    file.write(APD)
    file.write('\n')
    file.write(str(ActList))
    file.write('\n')
  except AttributeError as e:
    print("problem in ToWrite write e")
  finally:
    file.close()
  
Name=['antifungal','antiHIV','Antimalarial','Antioxidant','antiparasitic','antiprotists','antiviral','cancercells','Chemotactic','GramNList','GramPList','GramPNList','Insecticidal','proteaseI','Spermicidal','Surfaceimm','WoundH','MammalianCells']

  
for i in range(1,2902):
  tem=str(10000+i)
  tem=tem[1:]
  [APD,ActList]=Main(tem)
  st="ActOfAllAPD"
  ToWrite(APD,ActList,st)




