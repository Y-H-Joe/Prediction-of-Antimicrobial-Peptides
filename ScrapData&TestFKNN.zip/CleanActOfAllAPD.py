# -*- coding: utf-8 -*-
"""
Created on Tue Sep  5 12:05:06 2017

@author: 23712
"""
  

APD=[]
ACT=[]
with open("ActOfAllAPD.txt","r") as f:
  for line in f:
    if( line[0:1]=='>'):
      APD.append(line.strip())
      continue
    ACT.append(line.strip())
    
print(type(ACT[1]))    
dic={}      
dic=dict(zip(APD,ACT))
dic2={}
with open("CleanActOfAllAPD.txt","w") as f:    
  for i in dic.items():
    if(i[1]!='[]'):
      dic2[i[0]]=i[1]
  for i in dic2.items():
    i=str(i)
    f.write(i)
    f.write('\n')

      
    
    
    






